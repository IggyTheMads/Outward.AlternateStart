## Alternate Start
Experience 17 New Start Scenarios with an alternate intro Quest, some with unique gameplay changes to spice new playthroughs or join factions immediately!

HUMONGOUS THANKS TO SINAI & EMO FOR MAKING THIS POSSIBLE <3

OVERVIEW-------------------------------------------------------------

New playthroughs start in heaven, where you can choose your new start.

You can choose between 12 Backstory Scenarios, where your player will be given buffs and debuffs to spice gameplay and have a different short intro quest that lets you join a faction immediately. 
If you prefer vanilla, you can choose between 5 Vanilla-like scenarios, with no changes other than start location and skip to faction join.

(In Multiplayer, scenario is defined by host player 1, but other players can still choose their own starting perks)

------ Backstory Scenarios -------

-[Conflux Watcher] Passive mana regen, but reduced stamina regen.

-[Harmattan Trader] Reduced buy prices, but slightly reduced resistances.

-[War Veteran] Greatly increased hp, but the lowest your stamina, the lower your impact resistance and movement speed.

-[Enmerkar Hunter] Draw bows a lot faster, but deal less damage and impact with any other weapon.

-[Giant Risen] You are immovable,  increasing impact resistance and impact damage, but stamina actions cost more and Dodge is slower.

-[Slums Beggar] Easier to satisfy needs, bonus weather resistance and increased move speed. Reduced Stamina and HP.

-[Slave] Increased pouch size, max stamina  and physical damage, but you bleed very easily from taking physical damage.

-[Wolfgang Mercenary] Deal more damage per current stamina point. But have reduced magic resistances.

-[Priest of Elatt] You deal less base damage, but all damage dealt is converted into electric/holy damage.

-[Survivor] Deal bonus damage when below 75%. Gain the Rage buff when bellow 50% hp. Gain bonus attack speed when bellow 25%. But reduces All resistances.

-[Corrupted Soul] Permanently at 90% corruption, but also makes you immune to any kind of poisoning.

-[Claustrophobic] Wearing a helmet quickly drains stamina, however, when not wearing a helmet, greatly reduces stamina costs, mana costs and cooldowns.

------ Vanilla-like Scenarios -------

-[Vanilla-like: Cierzo]: Spawn in an alternate shipwreck in chersonese, ready to join any faction.

-[Vanilla-like: Berg]: Spawn at the edge of the Enmerkar river, ready to join any faction.

-[Vanilla-like: Levant]: Spawn at a pile of bones in the Abrassar desert, ready to join any faction.

-[Vanilla-like: Monsoon]: Spawn at a shipwreck in the hallowed marsh, ready to join any faction.

-[Vanilla-like: Harmattan]: Spawn at a shipwreck in the antique plateau, ready to join any faction.

------- ROADMAP --------

----Version 1.0-----

-12 Backstory Scenarios + 5 Vanilla-like Scenarios

---- Update 1.X ----

-2 New "Outlaw" Scenarios (Cannibal & Bandit) + 3 New Backstory Scenario (Ugly AF & Nightmares & Chosen One)

---- Update 1.XX ----

-More Backstory and Outlaw Scenarios

-Home purchasing regardless of faction

---- Update 2.0 ----

-New Custom Questslines & Side Activities (not scenario specific)

------------------------------------------
HUMONGOUS THANKS TO SINAI & EMO FOR MAKING THIS POSSIBLE <3
Thanks to everyone in the modding discord, specially those who provided feedback or ideas <3

------------CHANGELOG-------------- (unlisted releases are just bugfixes)

v1.0.1 - Launch of AlternateStart with 17 Scenarios.